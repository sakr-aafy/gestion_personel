

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="fas fa-list"></i> Liste des Personnes</h2>

    <div class="d-flex align-items-center gap-4">
        <!-- Bouton Ajouter une personne -->
        <a href="<?php echo e(route('people.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Ajouter une personne
        </a>

        <!-- Informations utilisateur + déconnexion (seulement si connecté) -->
        <?php if(auth()->guard()->check()): ?>
            <div class="d-flex align-items-center text-white">
                <span class="me-3">
                    <i class="fas fa-user-circle"></i>
                    <?php echo e(Auth::user()->name); ?>

                </span>

                <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-light btn-sm">
                        <i class="fas fa-sign-out-alt"></i> Déconnexion
                    </button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Formulaire de recherche -->
<div class="card mb-4">
    <div class="card-body">
        <form action="<?php echo e(route('people.index')); ?>" method="GET" class="row g-3">
            <div class="col-md-5">
                <input type="text" name="search" class="form-control"
                       placeholder="Rechercher par nom, prénom, email ou téléphone..."
                       value="<?php echo e(request('search')); ?>">
            </div>

            <div class="col-md-4">
                <select name="ville" class="form-select">
                    <option value="">Toutes les villes</option>
                    <?php $__currentLoopData = $villes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ville): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ville); ?>" <?php echo e(request('ville') == $ville ? 'selected' : ''); ?>>
                            <?php echo e($ville); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-3">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-search"></i> Rechercher
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Tableau des personnes -->
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Nom</th>
                        <th>Prénom</th>
                        <th>Email</th>
                        <th>Téléphone</th>
                        <th>Ville</th>
                        <th>Date de naissance</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($person->id); ?></td>
                            <td><?php echo e($person->nom); ?></td>
                            <td><?php echo e($person->prenom); ?></td>
                            <td><?php echo e($person->email); ?></td>
                            <td><?php echo e($person->telephone ?? '-'); ?></td>
                            <td><?php echo e($person->ville ?? '-'); ?></td>
                            <td><?php echo e($person->date_naissance ? $person->date_naissance->format('d/m/Y') : '-'); ?></td>
                            <td>
                                <a href="<?php echo e(route('people.edit', $person)); ?>" class="btn btn-sm btn-warning" title="Modifier">
                                    <i class="fas fa-edit"></i>
                                </a>

                                <form action="<?php echo e(route('people.destroy', $person)); ?>"
                                      method="POST"
                                      class="d-inline"
                                      onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer cette personne ?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" title="Supprimer">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center py-4">Aucune personne trouvée</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="mt-4">
            <?php echo e($people->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\project-laravel\gestion-personnes\resources\views/people/index.blade.php ENDPATH**/ ?>